package StepDefinition;
import Pages.JobPage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class JobSteps {
    WebDriver _driver;

    public JobSteps(WebDriver driver)
    {
        _driver = driver;
    }
    JobPage jobPage;

        @When("I navigate to (.*) from Job dropdown")
    public void WhenINavigateToFromDropdown(String dropdownOption)
    {
        jobPage.ClickJob();
        {
            switch (dropdownOption.toLowerCase())
            {
                case "pay grades":
                    jobPage.ClickPayGrades();
                    break;
                default:
                    break;
            }
        }
    }

        @When("I have added (.*) in Pay Grades")
    public void WhenIHaveAddedInPayGrades(String payGradeName)
    {
        jobPage.AddPayGrade(payGradeName);
    }

        @When("I have validated Successfull message")
    public void WhenIHaveValidatedSuccessfullMessage()
    {
       // Assert.assertTrue(jobPage.IsSuccessMessageDisplayed());
    }

        @When("I click on Add in Assigned Currencies")
    public void WhenIClickOnAddInAssignedCurrencies()
    {
        jobPage.ClickAddCurrency();
    }

        @When("I added curreny with below details")
    public void WhenIAddedCurrenyWithBelowDetails(DataTable data)
    {
        var table = data.asList();
            jobPage.SaveCurrencies(table.get(1), table.get(2), table.get(3));
    }

        @Then("Verify the saved curreny in assigned currencies table")
    public void ThenVerifyTheSavedCurrenyInAssignedCurrenciesTable(DataTable data)
    {
        List<String> values = new ArrayList<String>();
        var table = data.asList();
            values.add(table.get(1)); values.add(table.get(2)); values.add(table.get(3));
        Assert.assertTrue(jobPage.ValidateCurrenciesTableValues(values));
    }
}
