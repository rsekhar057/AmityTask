package StepDefinition;
import Pages.DirectoryPage;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class DirectorySteps {
    WebDriver _driver;

    public DirectorySteps(WebDriver driver)
    {
        _driver = driver;
    }
    DirectoryPage directoryPage;

        @When("I enter (.*) in Name textfield")
    public void WhenIEnterInNameTextfield(String txtName)
    {
        directoryPage.EnterSearchEmployee(txtName);
    }

        @When("I select (.*) in Location dropdown")
    public void WhenISelectInLocationDropdown(String option)
    {
        directoryPage.SelectLocation(option);
    }

        @When("I click on Search button")
    public void WhenIClickOnSearchButton()
    {
        directoryPage.ClickSearch();
    }

        @Then("I see search (.*) is available in search result")
    public void ThenISeeSearchIsAvailableInSearchResult(String txtSearchValue)
    {
        Assert.assertTrue(directoryPage.ValidateListContainsText(txtSearchValue));
    }
}
