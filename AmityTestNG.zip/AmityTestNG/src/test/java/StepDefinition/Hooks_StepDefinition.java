package StepDefinition;

import Pages.FrameworkInitialize;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;

import java.net.MalformedURLException;

public class Hooks_StepDefinition extends FrameworkInitialize{
    @Before
    public void setUP() throws MalformedURLException {
        InitializeBrowser(
                "Chrome");
    }

    @After
    public void tearDown()
    {
        driver.quit();
    }
}
