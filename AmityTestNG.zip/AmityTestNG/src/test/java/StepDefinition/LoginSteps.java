package StepDefinition;

import Pages.HomePage;
import Pages.JobPage;
import Pages.LoginPage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginSteps {
    WebDriver _driver;

    public LoginSteps(WebDriver driver)
    {
        _driver = driver;
    }
    HomePage homePage;
    LoginPage loginPage;
    @Given("I navigate to application")
    public void GivenINavigateToApplication()
    {
        _driver.get("https://opensource-demo.orangehrmlive.com/");
    }

        @Given("I enter username and password")
    public void GivenIEnterUsernameAndPassword(DataTable data)
    {
        var table = data.asList();
        loginPage.EnterUserNameAndPassword(table.get(1), table.get(2));
    }

        @Given("I click login")
    public void GivenIClickLogin()
    {
        loginPage.ClickLogin();
    }

        @Then("I should see user logged in to the application")
    public void ThenIShouldSeeUserLoggedInToTheApplication()
    {
        Assert.assertEquals(homePage.IsHomePage(),"True", "Market place button did not displayed");
    }

        @When("I Click (.*) tab in home page")
    public void WhenIClickTabInHomePage(String tabName)
    {
        homePage.ClickMenuOption(tabName);
    }
}
