package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.net.MalformedURLException;

public class FrameworkInitialize {

    public static WebDriver driver;

    public static void InitializeBrowser(String browserType) throws MalformedURLException {
        switch (browserType)
        {
            case "Chrome":
            {
                System.setProperty("webdriver.chrome.driver", "C:\\Users\\gr001\\Downloads\\chromedriver_win32\\chromedriver.exe");
                ChromeOptions chromeOptions = new ChromeOptions();

                driver= new ChromeDriver(chromeOptions);
                break;
            }
            case "Firefox":
            {
                //Open the browser
                System.setProperty("webdriver.gecko.driver", "C:\\chromedriver\\geckodriver.exe");
               FirefoxOptions firefoxOptions = new FirefoxOptions();

                driver= new FirefoxDriver(firefoxOptions);
                break;
            }
            case "IE":
            {
                break;
            }

        }
    }


}
