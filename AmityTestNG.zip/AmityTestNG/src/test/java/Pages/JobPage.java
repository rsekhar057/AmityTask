package Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class JobPage {
    WebDriver _driver;

    public JobPage(WebDriver driver)
    {
        _driver = driver;
        PageFactory.initElements(_driver,this);
    }
    @FindBy(how = How.XPATH, using = "//a[@id='menu_admin_Job']")
    public WebElement dropdownJob;

    @FindBy(how = How.XPATH, using = "//a[@id='menu_admin_viewPayGrades']")
    public WebElement btnPayGrades;

    @FindBy(how = How.XPATH, using = "//input[@id='btnAdd']")
    public WebElement btnPayGradesAdd;

    @FindBy(how = How.XPATH, using = "//input[@id='btnSave']")
    public WebElement btnPayGradesSave;

    @FindBy(how = How.XPATH, using = "//input[@id='payGrade_name']")
    public WebElement txtPayGradeName;

    @FindBy(how = How.XPATH, using = "//input[@id='btnAddCurrency']")
    public WebElement btnAddCurrency;

    @FindBy(how = How.XPATH, using = "//input[@id='payGradeCurrency_currencyName']")
    public WebElement txtCurrencyName;

    @FindBy(how = How.XPATH, using = "//input[@id='payGradeCurrency_minSalary']")
    public WebElement txtMinimumSalary;

    @FindBy(how = How.XPATH, using = "//input[@id='payGradeCurrency_maxSalary']")
    public WebElement txtMaximumSalary;

    @FindBy(how = How.XPATH, using = "//input[@id='btnSaveCurrency']")
    public WebElement btnSaveCurrency;

    @FindBy(how = How.XPATH, using = "//table[@id='tblCurrencies']//tbody//tr//td")
    public List<WebElement> tblCurrencies;

    public void SaveCurrencies(String txtCurreny, String txtMinSalary, String txtMaxSalary)
    {
        txtCurrencyName.sendKeys(txtCurreny);
        ClickMinSalary();
        txtMinimumSalary.sendKeys(txtMinSalary);
        txtMaximumSalary.sendKeys(txtMaxSalary);
        btnSaveCurrency.click();
    }
    public void ClickJob() {
        dropdownJob.click();
    }
    public void ClickMinSalary() { txtMinimumSalary.click();}
    public void ClickPayGrades() { btnPayGrades.click();}
    public void ClickAddCurrency() { btnAddCurrency.click();}
    public void AddPayGrade(String payGradeName)
    {
        btnPayGradesAdd.click();
        txtPayGradeName.sendKeys(payGradeName);
        btnPayGradesSave.click();
    }

    public boolean ValidateCurrenciesTableValues(List<String> values)
    {
        boolean isExists = false;int j = 0;
        for (int i = 1; i < tblCurrencies.size(); i++)
        {
            if (tblCurrencies.get(i).toString().equals(values.get(j)))
            {
                isExists = true;
            }
            j++;
        }
        return isExists;
    }
}
