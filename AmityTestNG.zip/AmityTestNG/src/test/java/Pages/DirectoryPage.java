package Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.Locale;

public class DirectoryPage {
    WebDriver _driver;

    public DirectoryPage(WebDriver driver)
    {
        _driver = driver;
        PageFactory.initElements(_driver,this);
    }
    @FindBy(how = How.ID, using = "searchDirectory_emp_name_empName")
    public WebElement txtEmployeeSearchField;

    @FindBy(how = How.ID, using = "searchDirectory_location")
    public WebElement drpdwnLocation;

    @FindBy(how = How.ID, using = "searchBtn")
    public WebElement btnSearch;

    @FindBy(how = How.XPATH, using = "//table//tr//td//ul//li//b")
    public List<WebElement> lstEmployeeNames;

    @FindBy(how = How.XPATH, using = "//select[@id='searchDirectory_location']//option")
    public List<WebElement> lstLocationNames;

    public void SelectLocation(String menuOption)
    {
        drpdwnLocation.click();
        for (int i = 0; i < lstLocationNames.size(); i++)
        {
            if(lstLocationNames.get(i).getText().contains(menuOption))
            {
                lstLocationNames.get(i).click();
            }
        }
    }

    public boolean ValidateListContainsText(String input)
    {
        boolean isExists=false;
        for (int i = 0; i < lstEmployeeNames.size(); i++)
        {
            if(lstEmployeeNames.get(i).getText().toLowerCase().contains(input))
            {
                isExists = true;
            }
        }
        return isExists;
    }

    public void EnterSearchEmployee(String empName)
    {
        txtEmployeeSearchField.sendKeys(empName);
    }

    public void ClickSearch()
    {
        btnSearch.click();
    }
}
