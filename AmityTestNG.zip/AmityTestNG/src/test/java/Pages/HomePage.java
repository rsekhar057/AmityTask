package Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.Locale;

public class HomePage {
    WebDriver _driver;

    public HomePage(WebDriver driver)
    {
        _driver = driver;
        PageFactory.initElements(_driver,this);
    }
    @FindBy(how = How.ID, using = "menu_directory_viewDirectory")
    public WebElement menuOptionDirectory;

    @FindBy(how = How.ID, using = "menu_admin_viewAdminModule")
    public WebElement menuOptionAdmin;

    @FindBy(how = How.ID, using = "MP_link")
    public WebElement lblMarketPlace;

    public boolean IsHomePage() {return lblMarketPlace.isDisplayed();}

    public void ClickMenuOption(String menuOption)
    {
        switch (menuOption.toLowerCase())
        {
            case "directory":
                menuOptionDirectory.click();
                break;
            case "admin":
                menuOptionAdmin.click();
                break;
            default:
                break;
        }
    }
}
