package Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

    WebDriver driver;

    public LoginPage(WebDriver driver)
    {
        driver = driver;
        PageFactory.initElements(driver,this);
    }
    @FindBy(how = How.ID, using = "logInPanelHeading")
    public WebElement lblLoginPanel;

    @FindBy(how = How.ID, using = "txtUsername")
    public WebElement txtUserName;

    @FindBy(how = How.ID, using = "txtPassword")
    public WebElement txtPassword;

    @FindBy(how = How.ID, using = "btnLogin")
    public WebElement btnLogin;

    public void EnterUserNameAndPassword(String userName, String password) {
        txtUserName.sendKeys(userName);
        txtPassword.sendKeys(password);
    }

    public void ClickLogin() {
        btnLogin.click();
    }

    public boolean IsLoginPage() {
        return lblLoginPanel.isDisplayed();
    }
}
