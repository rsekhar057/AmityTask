﻿using NUnit.Framework;
using SeleniumCSharpNetCore.Pages;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace SeleniumCSharpNetCore.Steps
{

    [Binding]
    public class JobSteps
    {

        private DriverHelper _driverHelper;
        JobPage jobPage;
        public JobSteps(DriverHelper driverHelper)
        {
            _driverHelper = driverHelper;
            jobPage = new JobPage(_driverHelper.Driver);
        }

        [When(@"I navigate to ""(.*)"" from Job dropdown")]
        public void WhenINavigateToFromDropdown(string dropdownOption)
        {
            jobPage.ClickJob();
            {
                switch (dropdownOption.ToLower())
                {
                    case "pay grades":
                        jobPage.ClickPayGrades();
                        break;
                    default:
                        break;
                }
            }
        }

        [When(@"I have added ""(.*)"" in Pay Grades")]
        public void WhenIHaveAddedInPayGrades(string payGradeName)
        {
            jobPage.AddPayGrade(payGradeName);
        }

        [When(@"I have validated Successfull message")]
        public void WhenIHaveValidatedSuccessfullMessage()
        {
            Assert.IsTrue(jobPage.IsSuccessMessageDisplayed());
        }

        [When(@"I click on Add in Assigned Currencies")]
        public void WhenIClickOnAddInAssignedCurrencies()
        {
            jobPage.ClickAddCurrency();
        }

        [When(@"I added curreny with below details")]
        public void WhenIAddedCurrenyWithBelowDetails(Table table)
        {
            for (int i = 0; i < table.RowCount; i++)
            {
                jobPage.SaveCurrencies(table.Rows[i]["txtCurreny"], table.Rows[i]["txtMinSalary"], table.Rows[i]["txtMaxSalary"]);
            }
        }

        [Then(@"Verify the saved curreny in assigned currencies table")]
        public void ThenVerifyTheSavedCurrenyInAssignedCurrenciesTable(Table table)
        {
            List<string> values = new List<string>();
            for (int i = 0; i < table.RowCount; i++)
            {
                values.Add(table.Rows[i]["lblCurrent"]); values.Add(table.Rows[i]["lblMinSalary"]); values.Add(table.Rows[i]["lblMaxSalary"]);
            }
            Assert.IsTrue(jobPage.ValidateCurrenciesTableValues(values));
        }

    }
}
