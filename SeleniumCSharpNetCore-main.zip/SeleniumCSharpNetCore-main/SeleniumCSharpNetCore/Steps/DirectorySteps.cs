﻿using NUnit.Framework;
using SeleniumCSharpNetCore.Pages;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace SeleniumCSharpNetCore.Steps
{

    [Binding]
    public class DirectorySteps
    {

        private DriverHelper _driverHelper;
        DirectoryPage directoryPage;
        public DirectorySteps(DriverHelper driverHelper)
        {
            _driverHelper = driverHelper;
            directoryPage = new DirectoryPage(_driverHelper.Driver);
        }

        [When(@"I enter ""(.*)"" in Name textfield")]
        public void WhenIEnterInNameTextfield(string txtName)
        {
            directoryPage.EnterSearchEmployee(txtName);
        }

        [When(@"I select ""(.*)"" in Location dropdown")]
        public void WhenISelectInLocationDropdown(string option)
        {
            directoryPage.SelectLocation(option);
        }

        [When(@"I click on Search button")]
        public void WhenIClickOnSearchButton()
        {
            directoryPage.ClickSearch();
        }

        [Then(@"I see search ""(.*)"" is available in search result")]
        public void ThenISeeSearchIsAvailableInSearchResult(string txtSearchValue)
        {
            Assert.IsTrue(directoryPage.ValidateListContainsText(txtSearchValue));
        }


    }
}
