﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumCSharpNetCore.Pages
{
    public class JobPage
    {
        private IWebDriver Driver;

        public JobPage(IWebDriver driver)
        {
            Driver = driver;
        }

        IWebElement dropdownJob => Driver.FindElement(By.XPath("//a[@id='menu_admin_Job']"));
        IWebElement btnPayGrades => Driver.FindElement(By.XPath("//a[@id='menu_admin_viewPayGrades']"));
        IWebElement btnPayGradesAdd => Driver.FindElement(By.XPath("//input[@id='btnAdd']"));
        IWebElement btnPayGradesSave => Driver.FindElement(By.XPath("//input[@id='btnSave']"));
        IWebElement txtPayGradeName => Driver.FindElement(By.XPath("//input[@id='payGrade_name']"));
        IWebElement lblSuccessfull => Driver.FindElement(By.XPath("//div[@id='payGrade']//div[@class='inner']/div[1]"));
        IWebElement btnAddCurrency => Driver.FindElement(By.XPath("//input[@id='btnAddCurrency']"));
        public IWebElement txtCurrencyName => Driver.FindElement(By.XPath("//input[@id='payGradeCurrency_currencyName']"));
        public IWebElement txtMinimumSalary => Driver.FindElement(By.XPath("//input[@id='payGradeCurrency_minSalary']"));
        public IWebElement txtMaximumSalary => Driver.FindElement(By.XPath("//input[@id='payGradeCurrency_maxSalary']"));
        public IWebElement btnSaveCurrency => Driver.FindElement(By.XPath("//input[@id='btnSaveCurrency']"));
        public IList<IWebElement> tblCurrencies => Driver.FindElements(By.XPath("//table[@id='tblCurrencies']//tbody//tr//td"));



        public bool IsSuccessMessageDisplayed() => lblSuccessfull.Displayed;

        public void SaveCurrencies(string txtCurreny, string txtMinSalary, string txtMaxSalary)
        {
            txtCurrencyName.SendKeys(txtCurreny);
            ClickMinSalary();
            txtMinimumSalary.SendKeys(txtMinSalary);
            txtMaximumSalary.SendKeys(txtMaxSalary);
            btnSaveCurrency.Click();
        }
        public void ClickJob() => dropdownJob.Click();
        public void ClickMinSalary() => txtMinimumSalary.Click();

        public void ClickSaveCurrency() => btnSaveCurrency.Click();
        public void ClickPayGrades() => btnPayGrades.Click();
        public void ClickAddCurrency() => btnAddCurrency.Click();
        public void AddPayGrade(string payGradeName)
        {
            btnPayGradesAdd.Click();
            txtPayGradeName.SendKeys(payGradeName);
            btnPayGradesSave.Click();
        }

        public bool ValidateCurrenciesTableValues(List<string> values)
        {
            bool isExists = false;int j = 0;
            for (int i = 1; i < tblCurrencies.Count; i++)
            {
                if (tblCurrencies[i].Text.Equals(values[j]))
                {
                    isExists = true;
                }
                j++;
            }
            return isExists;
        }

        public void JavaScriptExecutor(IWebElement webElement,string value)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver;
            js.ExecuteScript("arguments[0].setAttribute('value', '" + value + "')", webElement);
        }
    }
}
