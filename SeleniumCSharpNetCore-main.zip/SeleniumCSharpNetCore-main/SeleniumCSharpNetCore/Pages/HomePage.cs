﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumCSharpNetCore.Pages
{
    class HomePage
    {
        private IWebDriver Driver;

        public HomePage(IWebDriver driver)
        {
            Driver = driver;
        }

        IWebElement menuOptionDirectory => Driver.FindElement(By.Id("menu_directory_viewDirectory"));

        IWebElement menuOptionAdmin => Driver.FindElement(By.Id("menu_admin_viewAdminModule"));


        IWebElement lblMarketPlace => Driver.FindElement(By.Id("MP_link"));

        public bool IsHomePage() => lblMarketPlace.Displayed;

        public void ClickMenuOption(string menuOption)
        {
            switch (menuOption.ToLower())
            {
                case "directory":
                    menuOptionDirectory.Click();
                    break;
                case "admin":
                    menuOptionAdmin.Click();
                    break;
                default:
                    break;
            }
        }
    }
}
