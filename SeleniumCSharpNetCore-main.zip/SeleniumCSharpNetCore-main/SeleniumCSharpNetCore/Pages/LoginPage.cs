﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumCSharpNetCore.Pages
{
    public class LoginPage
    {
        private IWebDriver Driver;

        public LoginPage(IWebDriver driver)
        {
            Driver = driver;
        }

        IWebElement txtUserName => Driver.FindElement(By.Id("txtUsername"));
        IWebElement txtPassword => Driver.FindElement(By.Id("txtPassword"));
        IWebElement btnLogin => Driver.FindElement(By.Id("btnLogin"));
        IWebElement lblLoginPanel => Driver.FindElement(By.Id("logInPanelHeading"));


        public void EnterUserNameAndPassword(string userName, string password)
        {
            txtUserName.SendKeys(userName);
            txtPassword.SendKeys(password);
        }

        public void ClickLogin()
        {
            btnLogin.Click();
        }

        public bool IsLoginPage()
        {
            return lblLoginPanel.Displayed;
        }
    }
}
