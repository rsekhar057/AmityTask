﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium.Support.UI;

namespace SeleniumCSharpNetCore.Pages
{
    class DirectoryPage
    {
        private IWebDriver Driver;

        public DirectoryPage(IWebDriver driver)
        {
            Driver = driver;
        }

        IWebElement txtEmployeeSearchField => Driver.FindElement(By.Id("searchDirectory_emp_name_empName"));
        IWebElement drpdwnLocation => Driver.FindElement(By.Id("searchDirectory_location"));
        IWebElement btnSearch => Driver.FindElement(By.Id("searchBtn"));
        IList<IWebElement> lstEmployeeNames => Driver.FindElements(By.XPath("//table//tr//td//ul//li//b"));
        IList<IWebElement> lstLocationNames => Driver.FindElements(By.XPath("//select[@id='searchDirectory_location']//option"));

        public void SelectLocation(string menuOption)
        {
            drpdwnLocation.Click();
            for (int i = 0; i < lstLocationNames.Count; i++)
            {
                if(lstLocationNames[i].Text.Contains(menuOption))
                {
                    lstLocationNames[i].Click();
                }
            }
        }

        public bool ValidateListContainsText(string input)
        {
            bool isExists=false;
            for (int i = 0; i < lstEmployeeNames.Count; i++)
            {
                if(lstEmployeeNames[i].Text.ToLower().Contains(input))
                {
                    isExists = true;
                }
            }
            return isExists;
        }

        public void EnterSearchEmployee(string empName)
        {
            txtEmployeeSearchField.SendKeys(empName);
        }

        public void ClickSearch()
        {
            btnSearch.Click();
        }
    }
}
